#[allow(unused)]
fn main() {
    let data = ["<--", "#####", "<=="].map(|v| v.to_string());
    let test1 = vflip(&data);
    let test2 = hflip(&data);
    let test3 = hcat(&data[..2], &data);
    // print!("{:?}", &test1);
    // print!("{:?}", &test2);
    print!("{:?}", &test3);
}

//Q1
fn vflip(v: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    for i in v.iter().rev() {
        out.push(i.to_string());
    }
    out
}

fn hflip(v: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    let mut max_len = 0;
    for i in v.iter() {
        if i.len() > max_len {
            max_len = i.len();
        }
    }
    for i in v.iter() {
        let mut flipped = String::new();
        for j in i.chars().rev() {
            flipped.push(j);
        }
        while flipped.len() < max_len  {
            flipped.insert(0, ' ');
        }
        out.push(flipped);
    }
    out
}

#[test]
fn test_img_flip() {
    let emp = ["".to_string(); 0];
    assert_eq!(vflip(&emp), [""; 0]);
    assert_eq!(hflip(&emp), [""; 0]);

    let data = [
        "<--", 
        "#####", 
        "<=="].map(|v| v.to_string());
    assert_eq!(
        vflip(&data), [
            "<==", 
            "#####", 
            "<--"]);
    assert_eq!(
        hflip(&data), [
            "  --<", 
            "#####", 
            "  ==<"]);
}




#[allow(dead_code)]
//Q2
fn vcat(v1: &[String], v2: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    for i in v1.iter() {
        out.push(i.to_string())
    }
    for j in v2.iter() {
        out.push(j.to_string())
    }
    out
}

fn are_all_chars_same(v: &str) -> bool {
    match v.chars().next() {
        Some(first_char) => v.chars().all(|c| c == first_char),
        None => true,
    }
}

fn hcat(v1: &[String], v2: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    let max_len = v1.len().max(v2.len());

    for i in 0..max_len {
        let front: String = if i < v1.len() {
            v1[i].clone()
        } else {
            " ".repeat(max_len + 1)
        };
        let back: String = if i < v2.len() {
            v2[i].clone()
        } else {
            String::new()
        };

        let combined: String = if i < v1.len() && i < v2.len() {
            if front == back && are_all_chars_same(&front) {
                front + &back
            } else {
                front + " " + &back
            }
        } else if i < v1.len() {
            format!("{:width$}", front, width = max_len)
        } else {
            front + &back
        };

        out.push(combined);
    }

    out
}

#[test]
fn test_img_cat() {
    let emp = ["".to_string(); 0];
    assert_eq!(vcat(&emp, &emp), [""; 0]);
    assert_eq!(hcat(&emp, &emp), [""; 0]);

    let data = [
        "<--", 
        "#####", 
        "<=="].map(|v| v.to_string());
    assert_eq!(vcat(&emp, &data), data);
    assert_eq!(vcat(&data, &emp), data);

    assert_eq!(
        vcat(&data, &data),
        ["<--", 
        "#####", 
        "<==", 
        "<--", 
        "#####", 
        "<=="]
    );
    assert_eq!(
        hcat(&data, &data[..2]), [
            "<-- <--", 
            "##########", 
            "<=="]);
    assert_eq!(
        hcat(&data[..2], &data), [
            "<-- <--", 
            "##########", 
            "    <=="]);
}



// // Find the maximum length of the strings in v1
// for i in v1.iter() {
//     if i.len() > max_len {
//         max_lenv1 = i.len();
//     }
// }
// for i in v2.iter() {
//     if i.len() > max_len {
//         max_lenv2 = i.len();
//     }
// }
