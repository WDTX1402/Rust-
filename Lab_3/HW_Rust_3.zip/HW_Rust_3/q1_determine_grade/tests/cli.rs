use assert_cmd::Command;

#[test]
fn main() {
    let mut cmd = Command::cargo_bin("q1_determine_grade").unwrap();
    cmd.arg("95").assert().success().stdout("Excellent A+");
}

#[test]
fn main1() {
    let mut cmd = Command::cargo_bin("q1_determine_grade").unwrap();
    cmd.arg("").assert().success().stdout("Invalid Score");
}

#[test]
fn main2() {
    let mut cmd = Command::cargo_bin("q1_determine_grade").unwrap();
    cmd.arg("bro").assert().success().stdout("Invalid Score");
}

#[test]
fn main3() {
    let mut cmd = Command::cargo_bin("q1_determine_grade").unwrap();
    cmd.arg("101").assert().success().stdout("Invalid Score");
}

#[test]
fn main4() {
    let mut cmd = Command::cargo_bin("q1_determine_grade").unwrap();
    cmd.arg("-1").assert().success().stdout("Invalid Score");
}