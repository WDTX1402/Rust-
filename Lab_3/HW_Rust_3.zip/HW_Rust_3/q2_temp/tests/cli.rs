use assert_cmd::Command;
use std::fs;
type TestResult = Result<(), Box<dyn std::error::Error>>;


#[test]
fn runs() -> TestResult {
    let expected = fs::read_to_string("tests/output.txt")?;
    let mut cmd = Command::cargo_bin("q2_temp")?;
    cmd.arg("0").arg("320").arg("40").assert().success().stdout(expected);

   Ok(())
}

#[test]
fn vroom() -> TestResult {
    let expected = fs::read_to_string("tests/output1.txt")?;
    let mut cmd = Command::cargo_bin("q2_temp")?;
    cmd.arg("0").arg("0").arg("0").assert().success().stdout(expected);

   Ok(())
}

#[test]
fn wee() -> TestResult {
    let expected = fs::read_to_string("tests/output2.txt")?;
    let mut cmd = Command::cargo_bin("q2_temp")?;
    cmd.arg("300").arg("0").arg("20").assert().success().stdout(expected);

   Ok(())
}

#[test]
fn imsad() -> TestResult {
    let mut cmd = Command::cargo_bin("q2_temp")?;
    cmd.arg("").assert().success().stdout("Invalid Input");

   Ok(())
}

#[test]
fn help() -> TestResult {
    let mut cmd = Command::cargo_bin("q2_temp")?;
    cmd.arg("I want to be a lawyer").assert().success().stdout("Invalid Input");

   Ok(())
}

