use assert_cmd::Command;
use std::fs;
type TestResult = Result<(), Box<dyn std::error::Error>>;

#[test]
fn amogus() -> TestResult {
    let expected = fs::read_to_string("tests/output.txt")?;
    let output = Command::cargo_bin("q3_2_usdpyramid")?.arg("0").output()?;
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();

    assert_eq!(stdout, expected, "Test failed");

    Ok(())
}
