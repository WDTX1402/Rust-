use assert_cmd::Command;

#[test]
fn main() {
    let mut cmd = Command::cargo_bin("determine_grade").unwrap();
    cmd.arg("69").assert().success().stdout("C");
}