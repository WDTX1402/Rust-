fn main() {
    let args: Vec<String> = std::env::args().collect();

    let mut i = 1;
    let mut v: Vec<f64> = Vec::new();

    while i < args.len() {
        if let Ok(num) = args[i].parse::<f64>() {
            v.push(num);
        }
        i += 1;
    }
    
    let mut x1 = v[0];
    let mut x2 = v[1];
    let mut x3 = v[2];
    
    let mut y: String = "<style>
    table, td {
        border: 1px solid #000000;
        border-collapse: collapse;
    }
    </style>
    <table WIDTH=50%>
    <tr>
        <th WIDTH=25%>Fahrenheit</th>
        <th WIDTH=25%>Celcius</th>
    </tr>".to_string();
    if x3 != 0.0 {
        if x1 < x2 {
            while x1 <= x2 {
                let fahr: f64 = x1;
                let cel: f64 = (5.0/9.0)*(fahr - 32.0);
                let l = format!("<tr>
                                    <td style=text-align:center>{}</td>
                                    <td style=text-align:center>{:.1}</td>
                                </tr>",
                                fahr,cel);
                y.push_str(&l);
                x1 += x3;
            }
        } else if x1 > x2 {
            while x1 >= x2 {
                let fahr: f64 = x1;
                let cel: f64 = (5.0/9.0)*(fahr - 32.0);
                let l = format!("<tr>
                                    <td style=text-align:center>{}</td>
                                    <td style=text-align:center>{:.1}</td>
                                </tr>",
                                fahr,cel);
                y.push_str(&l);
                x1 -= x3;
            }
        } else {
            let fahr: f64 = x1;
            let cel: f64 = (5.0/9.0)*(fahr - 32.0);
            let l = format!("<tr>
                                <td style=text-align:center>{}</td>
                                <td style=text-align:center>{:.1}</td>
                            </tr>",
                            fahr,cel);
            y.push_str(&l);
         } 
    } else {
        let fahr: f64 = x1;
        let cel: f64 = (5.0/9.0)*(fahr - 32.0);
        let l = format!("<tr>
                            <td style=text-align:center>{}</td>
                            <td style=text-align:center>{:.1}</td>
                        </tr>",
                        fahr,cel);
        y.push_str(&l);
    }
    y.push_str("</table>");
    print!("{}",y)
}
