use assert_cmd::Command;

#[test]
fn main() {
    let mut cmd = Command::cargo_bin("Q2_1").unwrap();
    cmd.arg("4").arg("5").arg("8").arg("9").arg("12").arg("3").assert().success().stdout("Ascending X: [(4.0, 5.0), (8.0, 9.0), (12.0, 3.0)]\nDescending X: [(12.0, 3.0), (8.0, 9.0), (4.0, 5.0)]\nAscending Y: [(12.0, 3.0), (4.0, 5.0), (8.0, 9.0)]\nDescending Y: [(8.0, 9.0), (4.0, 5.0), (12.0, 3.0)]\n");
}

#[test]
fn main1() {
    let mut cmd = Command::cargo_bin("Q2_1").unwrap();
    cmd.arg("4").arg("9").arg("8").arg("0").arg("3").arg("4").arg("2").assert().success().stdout("Ascending X: [(3.0, 4.0), (4.0, 9.0), (8.0, 0.0)]\nDescending X: [(8.0, 0.0), (4.0, 9.0), (3.0, 4.0)]\nAscending Y: [(8.0, 0.0), (3.0, 4.0), (4.0, 9.0)]\nDescending Y: [(4.0, 9.0), (3.0, 4.0), (8.0, 0.0)]\n");
}