// fn sortpoints() {
//     let args: Vec<String> = std::env::args().collect();
//     let mut inputs: Vec<(f64, f64)> = Vec::new();
//     let mut i = 1;
//     while i < args.len() {
//         if let (Ok(x), Ok(y)) = (args[i].parse::<f64>(), args[i + 1].parse::<f64>()) {
//             inputs.push((x, y));
//         }
//         i += 2;
//     }

//     let mut vectoorx = Vec::new();
//     let mut vectoory = Vec::new();

//     for i in 0..inputs.len() {
//         if i % 2 == 0 {
//             vectoorx.push(inputs[i].clone()); 
//         } else {
//             vectoory.push(inputs[i].clone()); 
//         }
//     }

//     let mut desdx = vectoorx.clone();
//     let mut ascdx = vectoorx.clone();

//     desdx.sort_by(|a, b| b.partial_cmp(a).unwrap()); // Sort descending
//     ascdx.sort_by(|a, b| a.partial_cmp(b).unwrap()); // Sort ascending

//     let mut desdy = vectoory.clone();
//     let mut ascdy = vectoory.clone();

//     desdy.sort_by(|a, b| b.partial_cmp(a).unwrap()); // Sort descending
//     ascdy.sort_by(|a, b| a.partial_cmp(b).unwrap()); // Sort ascending

//     println!("Descending X: {:?}", desdx);
//     println!("Ascending X: {:?}", ascdx);
//     println!("Descending Y: {:?}", desdy);
//     println!("Ascending Y: {:?}", ascdy);
// }


fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut v: Vec<f64> = args[1..].iter().map(|x| x.parse::<f64>().unwrap()).collect();
    if v.len() % 2 != 0 {
        v = v[..v.len()-1].to_vec()
    }
    let mut i = 1;
    let mut points: Vec<(f64, f64)> = Vec::new();
    while i < v.len() {
        points.push((v[i-1],v[i]));
        i += 2
    }
    

    let mut ascdx = points.clone();
    ascdx.sort_by(|a, b| a.partial_cmp(b).unwrap());


    let mut desdx = points.clone();
    desdx.sort_by(|a, b| b.partial_cmp(a).unwrap());


    let mut ascdy = points.clone();
    ascdy.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

  
    let mut desdy = points.clone();
    desdy.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());

 
    println!("Ascending X: {:?}", ascdx);
    println!("Descending X: {:?}", desdx);
    println!("Ascending Y: {:?}", ascdy);
    println!("Descending Y: {:?}", desdy);
}

