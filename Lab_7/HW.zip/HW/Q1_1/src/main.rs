fn sortnumber() {
    let mut args: Vec<String> = std::env::args().collect();
    let mut inputs: Vec<isize> = Vec::new();
    for i in 1..args.len() {
        if let Ok(num) = args[i].parse() {
            inputs.push(num);
        }
    }
    let mut vectoor = Vec::new();
    let mut desd = inputs.clone();
    let mut ascd = inputs.clone();
    
    desd.sort_by(|a, b| b.cmp(a)); // Sort descending
    ascd.sort_by(|a, b| a.cmp(b)); // Sort ascending

    vectoor.push((desd, ascd));

    print!("{:?}", vectoor);
}

fn main() {
   sortnumber();
}
