use assert_cmd::Command;

#[test]
fn main1() {
    let mut cmd = Command::cargo_bin("Q1_2").unwrap();
    cmd.arg("9").arg("5").arg("6").arg("3").assert().success().stdout("[([9, 6, 5, 3], [3, 5, 6, 9])]\n");
}