fn sortnumber() -> Vec<(Vec<isize>, Vec<isize>)> {
    let mut args: Vec<String> = std::env::args().collect();
    let mut inputs: Vec<isize> = Vec::new();
    for i in 1..args.len() {
        if let Ok(num) = args[i].parse() {
            inputs.push(num);
        }
    }

    let mut vectoor = Vec::new();
    let mut desd = inputs.clone();
    let mut ascd = inputs.clone();

    bubble_sort_descending(&mut desd);
    bubble_sort_ascending(&mut ascd);

    vectoor.push((desd, ascd));
    vectoor
}

fn bubble_sort_descending(arr: &mut Vec<isize>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j] < arr[j + 1] {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn bubble_sort_ascending(arr: &mut Vec<isize>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn main() {
    println!("{:?}", sortnumber());
}
