use assert_cmd::Command;

#[test]
fn main() {
    let mut cmd = Command::cargo_bin("Q2_2").unwrap();
    cmd.arg("4").arg("9").arg("8").arg("0").arg("3").arg("4").assert().success().stdout("Descending X: [(8.0, 0.0), (4.0, 9.0), (3.0, 4.0)]\nAscending X: [(3.0, 4.0), (4.0, 9.0), (8.0, 0.0)]\nDescending Y: [(4.0, 9.0), (3.0, 4.0), (8.0, 0.0)]\nAscending Y: [(8.0, 0.0), (3.0, 4.0), (4.0, 9.0)]\n");
}

#[test]
fn main1() {
    let mut cmd = Command::cargo_bin("Q2_2").unwrap();
    cmd.arg("4").arg("9").arg("8").arg("0").arg("3").arg("4").arg("2").assert().success().stdout("Descending X: [(8.0, 0.0), (4.0, 9.0), (3.0, 4.0)]\nAscending X: [(3.0, 4.0), (4.0, 9.0), (8.0, 0.0)]\nDescending Y: [(4.0, 9.0), (3.0, 4.0), (8.0, 0.0)]\nAscending Y: [(8.0, 0.0), (3.0, 4.0), (4.0, 9.0)]\n");
}