fn sortnumber() {
    let mut args: Vec<String> = std::env::args().collect();
    let mut v: Vec<f64> = args[1..].iter().map(|x| x.parse::<f64>().unwrap()).collect();
    if v.len() % 2 != 0 {
        v = v[..v.len()-1].to_vec()
    }
    let mut i = 1;
    let mut points: Vec<(f64, f64)> = Vec::new();
    while i < v.len() {
        points.push((v[i-1],v[i]));
        i += 2
    }
    



    let mut desdx = points.clone();
    let mut ascdx = points.clone();
    let mut desdy = points.clone();
    let mut ascdy = points.clone();


    bubble_sort_desdx(&mut desdx);
    bubble_sort_ascdx(&mut ascdx);
    bubble_sort_desdy(&mut desdy);
    bubble_sort_ascdy(&mut ascdy);

    println!("Descending X: {:?}", desdx);
    println!("Ascending X: {:?}", ascdx);
    println!("Descending Y: {:?}", desdy);
    println!("Ascending Y: {:?}", ascdy);
}

fn bubble_sort_desdx(arr: &mut Vec<(f64, f64)>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j].0 < arr[j + 1].0 {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn bubble_sort_ascdx(arr: &mut Vec<(f64, f64)>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j].0 > arr[j + 1].0 {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn bubble_sort_desdy(arr: &mut Vec<(f64, f64)>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j].1 < arr[j + 1].1 {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn bubble_sort_ascdy(arr: &mut Vec<(f64, f64)>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j].1 > arr[j + 1].1 {
                arr.swap(j, j + 1);
            }
        }
    }
}

fn main() {
    sortnumber();
}
