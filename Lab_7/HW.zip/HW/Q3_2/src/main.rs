fn main() {
    let args: Vec<String> = std::env::args().collect();

    if args.len() != 4 {
        println!("Usage: {} <x1> <x2> <x3>", args[0]);
        return;
    }

    let mut x1: f64 = match args[1].parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid argument for x1");
            return;
        }
    };

    let mut x2: f64 = match args[2].parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid argument for x2");
            return;
        }
    };

    let mut x3: f64 = match args[3].parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid argument for x3");
            return;
        }
    };

    let mut y: String = "<style>
    table, td {
        border: 1px solid #000000;
        border-collapse: collapse;
    }
    </style>
    <table WIDTH=50%>
    <tr>
        <th WIDTH=20%>x</th>
        <th WIDTH=20%>x^2</th>
        <th WIDTH=20%>x^3</th>
    </tr>".to_string();

    if x3 != 0. {
        if x1 < x2 {
            while x1 <= x2 {
                let x = x1;
                let xx = x.powf(2.0);
                let xxx = x.powf(3.0);
                let l = format!("<tr><td style=text-align:center>{:.2}</td>
                                    <td style=text-align:center>{:.2}</td>
                                    <td style=text-align:center>{:.2}</td>
                                </tr>",
                                x, xx, xxx);
                y.push_str(&l);
                x1 += x3;
            }
        } else if x1 > x2 {
            while x1 >= x2 {
                let x = x1;
                let xx = x.powf(2.0);
                let xxx = x.powf(3.0);
                let l = format!("<tr><td style=text-align:center>{:.2}</td>
                                    <td style=text-align:center>{:.2}</td>
                                    <td style=text-align:center>{:.2}</td>
                                </tr>",
                                x, xx, xxx);
                y.push_str(&l);
                x1 -= x3;
            }
        } else {
            let x = x1;
            let xx = x.powf(2.0);
            let xxx = x.powf(3.0);
            let l = format!("<tr><td style=text-align:center>{:.2}</td>
                                <td style=text-align:center>{:.2}</td>
                                <td style=text-align:center>{:.2}</td>
                            </tr>",
                            x, xx, xxx);
            y.push_str(&l);
        }
    } else {
        let x = x1;
        let xx = x.powf(2.);
        let xxx = x.powf(3.);
        let l = format!("<tr><td style=text-align:center>{:.2}</td>
                                <td style=text-align:center>{:.2}</td>
                                <td style=text-align:center>{:.2}</td>
                            </tr>",
                            x, xx, xxx);
        y.push_str(&l);
    }

    y.push_str("</table>");
    println!("{}", y);
}
