fn main() {}
fn min_max_avg(v: &Vec<i32>) -> (i32, i32, f64) {
    if v.is_empty() {
        return (0,0,0.0);
    }
    let mut min = v[0];
    let mut max = v[0];
    let mut sum = 0;

    for &num in v {
        if num < min {
            min = num;
        }
        if num > max {
            max = num;
        }
        sum += num;
    }

    let avg = sum as f64 / v.len() as f64;

    (min, max, avg)
}

#[test]
fn minmaxavgtest() {
    assert_eq!(min_max_avg(&vec![1, 2, 3, 4, 5]), (1, 5, 3.0));
    assert_eq!(min_max_avg(&vec![]), (0, 0, 0.0));
}



fn cal_partial_sum(v: &[isize]) -> Vec<isize> {
    let mut ans = Vec::new();
    let mut j = 0;
    for &i in v {
        j += i as isize;
        ans.push(j);

    }
    ans
}

#[test]
fn sumtest() {
    assert_eq!(cal_partial_sum(&[1,2,3,4,5]), vec![1,3,6,10,15]);
    assert_eq!(cal_partial_sum(&[1,2,3,4,-5]), vec![1,3,6,10,5]);
    assert_eq!(cal_partial_sum(&[]), vec![]);
}