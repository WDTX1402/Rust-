fn main() {}

fn unpack_number_tuples(v: &[(isize,isize)]) -> (Vec<isize>,Vec<isize>) {
    let mut ans1 = Vec::new();
    let mut ans2 = Vec::new();
    for (v1,v2) in v {
        ans1.push(*v1);
        ans2.push(*v2);
    }
    (ans1,ans2)
}

#[test]
fn unpack_number_tuples_tests() {
    assert_eq!(unpack_number_tuples(&[(1, 4), (3, 2), (2, 1)]),(vec![1, 3, 2], vec![4, 2, 1]));
    assert_eq!(unpack_number_tuples(&[]),(vec![], vec![]));
}

fn unpack_number_tuples3(v: &[(isize,isize,isize)]) -> (Vec<isize>,Vec<isize>,Vec<isize>) {
    if v.is_empty() {
        return (Vec::new(),Vec::new(),Vec::new());
    }
    else {
    let mut ans1 = Vec::new();
    let mut ans2 = Vec::new();
    let mut ans3 = Vec::new();
    for (v1,v2,v3) in v {
        ans1.push(*v1);
        ans2.push(*v2);
        ans3.push(*v3);
    }
    (ans1,ans2,ans3)
}
}

#[test]
fn unpack_number_tuples3_tests() {
    assert_eq!(unpack_number_tuples3(&[(1, 4, 5), (2, 2, 1)]),(vec![1, 2], vec![4, 2], vec![5, 1]));
    assert_eq!(unpack_number_tuples3(&[(8, 5, 6), (1, 4, 9)]),(vec![8, 1], vec![5, 4], vec![6, 9]));
    assert_eq!(unpack_number_tuples3(&[]),(vec![], vec![], vec![]));
}