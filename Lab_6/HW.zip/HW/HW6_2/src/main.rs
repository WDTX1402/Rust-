fn main() {}


fn pack_number_tuples3(v:&[isize], b:&[isize], c:&[isize]) -> Vec<(isize, isize, isize)> {
    if v.is_empty() || b.is_empty() || c.is_empty() {
        return Vec::new();
    } else {
        
    let mut ans = Vec::new();
    let max_len = v.len().max(b.len()).max(c.len());

    for i in 0..max_len {
        let ans1 = if i < v.len() { v[i] } else { 0 };
        let ans2 = if i < b.len() { b[i] } else { 0 };
        let ans3 = if i < c.len() { c[i] } else { 0 };
        ans.push((ans1, ans2, ans3));
    }
    ans
    }
}
#[test]
fn packnumbertuples3tests() {
    assert_eq!(pack_number_tuples3(&[1, 2], &[4, 3], &[5]),vec![(1, 4, 5), (2, 3, 0)]);
    assert_eq!(pack_number_tuples3(&[1, 2, 5], &[4, 3], &[5, 6, 7]), vec![(1, 4, 5),(2, 3, 6),(5, 0, 7)]);
    assert_eq!(pack_number_tuples3(&[], &[], &[]),vec![]);
}





fn pack_number_tuples_s3(v:&[isize], b:&[isize], c:&[isize]) -> Vec<(isize, isize, isize)> {
    if v.is_empty() || b.is_empty() || c.is_empty() {
        return Vec::new();
    } else {

    let mut ans = Vec::new();
    let min_len = v.len().min(b.len()).min(c.len());

    for i in 0..min_len {
        let ans1 = v[i];
        let ans2 = b[i];
        let ans3 = c[i];
        ans.push((ans1, ans2, ans3));
    }

    ans
    }
}

#[test]
fn testjoinstrings() {
    assert_eq!(pack_number_tuples_s3(&[1, 2], &[4, 3], &[5]), vec![(1, 4, 5)]);
    assert_eq!(pack_number_tuples_s3(&[1, 2, 5, 8], &[4, 3], &[5, 6, 7]), vec![(1, 4, 5),(2, 3, 6)]);
    assert_eq!(pack_number_tuples_s3(&[], &[], &[]), (vec![]));
}

