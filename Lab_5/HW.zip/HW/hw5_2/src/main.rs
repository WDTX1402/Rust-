fn split_grades<'a>(v: Vec<&str>) -> (Vec<&str>, Vec<&str>) {
    let mut good = Vec::new();
    let mut bad = Vec::new();
    for a in v {
        match a {
            "A+" | "A" | "B" | "C"  => {
                good.push(a)
            }
            "D" | "F" => {
                bad.push(a)
            }
            _ => {

            }

        } 
            
    }
    return (good,bad)
}
    


#[test]
fn test_split_grade() {
    assert_eq!(split_grades((&["B", "F", "A+", "D", "C"]).to_vec()),(vec!["B", "A+", "C"],vec!["F", "D"]));
    assert_eq!(split_grades((&[]).to_vec()),(vec![],vec![]));
    assert_eq!(split_grades((&["D","F"]).to_vec()),(vec![],vec!["D","F"]));
    assert_eq!(split_grades((&["B", "C", "A"]).to_vec()),(vec!["B", "C", "A"],vec![]));
}


fn split_scores(v: Vec<i32>) -> (Vec<(String, i32)>, Vec<(String, i32)>) {
    let mut good = Vec::new();
    let mut bad = Vec::new();

    for score in v {
        let grade = if score > 100 {
            "Invalid".to_string()
        } else if 95 <= score && score <= 100 {
            "A+".to_string()
        } else if 81 <= score && score <= 94 {
            "A".to_string()
        } else if 71 <= score && score <= 80 {
            "B".to_string()
        } else if 61 <= score && score <= 70 {
            "C".to_string()
        } else if 50 <= score && score <= 60 {
            "D".to_string()
        } else if 0 <= score && score <= 49 {
            "F".to_string()
        } else {
            "Invalid".to_string()
        };

        if grade == "D" || grade == "F" {
            bad.push((grade, score));
        } else {
            good.push((grade, score));
        }
    }

    (good, bad)
}


#[test]
fn test_split_score() {
    assert_eq!(split_scores(vec![1,90]),(vec![("A".to_string(), 90)],vec![("F".to_string(), 1)]));
    assert_eq!(split_scores(vec![]),(vec![],vec![]));
    assert_eq!(split_scores(vec![75, 42, 98, 54, 63]),(vec![("B".to_string(),
    75), ("A+".to_string(), 98), ("C".to_string(), 63)], vec![("F".to_string(), 42), ("D".to_string(), 54)]));
    assert_eq!(split_scores(vec![90]),(vec![("A".to_string(), 90)],vec![]));
    assert_eq!(split_scores(vec![1]),(vec![],vec![("F".to_string(), 1)]));
}
    

fn main() {}
            
    
    