fn main() {
}

fn extract_quoted_words(v: &str) -> Vec<String> {


    let mut a: Vec<String> = Vec::new();
    let b: Vec<&str> = v.split_whitespace().collect();

    for i in b {
        let mut c: Vec<char> = i.chars().collect();

        if c.len() > 2 {
            if c[0] == '*' && c[c.len() - 1] == '*' {
                let e = &i[1..];
                let f = &e[..e.len() - 1];
                a.push(f.to_string());
            }
        } else if i == "**" {
            a.push("".to_string());
        }
    }

    a
}


#[test]
fn test_extract_quoted_words() {
    assert_eq!(extract_quoted_words(""), Vec::<String>::new());
    assert_eq!(extract_quoted_words("C ** *C++* *Java *Python* Rust*"),["", "C++", "Python"]);
    assert_eq!(extract_quoted_words("****"),["**"]);
}

fn extract_quoted_words_r(v: &str) -> Vec<String> {
    let mut a: Vec<String> = Vec::new();
    let mut words = v.split_whitespace();
    
    if let Some(i) = words.next() {
        let mut c: Vec<char> = i.chars().collect();

        if c.len() > 2 || c.len() == 2{
            if c[0] == '*' && c[c.len() - 1] == '*' {
                let e = &i[1..];
                let f = &e[..e.len() - 1];
                a.push(f.to_string());
            } 
            else if i == "**" {
                a.push("".to_string());
        } 
        }
        
        a.extend(extract_quoted_words_r(words.collect::<Vec<&str>>().join(" ").as_str()));
    }
    
    a
}
#[test]
fn test_extract_quoted_words_r() {
    assert_eq!(extract_quoted_words_r(""), Vec::<String>::new());
    assert_eq!(extract_quoted_words_r("C ** *C++* *Java *Python* Rust*"),["", "C++", "Python"]);
    assert_eq!(extract_quoted_words_r("****"),["**"]);
}