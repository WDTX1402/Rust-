fn main() {}


fn count_vowels(v: &str) -> i64 {
    let mut c = 0;
    for a in v.chars() {
        if a.is_alphabetic() && "AEIOUaeiou".contains(a) {
            c += 1;
        }
    }
    c
}

#[test]
fn test_vowels_count0() {
    assert_eq!(count_vowels(""), 0);
    assert_eq!(count_vowels("abEcd"), 2);
    assert_eq!(count_vowels("ab12Exey5 7x8U3y5z"), 4);
}


fn count_vowels1(v: &str) -> i64 {
    if v.is_empty() {
        return 0;
    }
    let count = count_vowels1(&v[1..]);
    if v.chars().next().unwrap().is_alphabetic() && "AEIOUaeiou".contains(v.chars().next().unwrap())
    {
        return count + 1;
    } else {
        return count;
    }
}

#[test]
fn test_vowels_count1() {
    assert_eq!(count_vowels1(""), 0);
    assert_eq!(count_vowels1("abEcd"), 2);
    assert_eq!(count_vowels1("ab12Exey5 7x8U3y5z"), 4);
    assert_eq!(count_vowels1("ab1AAA2Exey5 7x8EEU3y5z"), 9);
}


fn count_vowels_v2(v: &str) -> Vec<(String, i32)> {
    let mut z = 0;
    let split = v.split_whitespace();
    let mut result = Vec::new();
    for i in split {
        z = 0;
        for c in i.chars() {
            if c.is_alphabetic()  && "AEIOUaeiou".contains(c) {
                z += 1;

            }
        }
        result.push((i.to_string(), z));
    }
    result
}




#[test]
fn test_vowels_count2() {
    assert_eq!(count_vowels_v2(""), []);
    assert_eq!(
        count_vowels_v2("ab12Exey5 7x8U3y5z"),
        [
            ("ab12Exey5".to_string(), 3), // 'a', 'E', 'e'
            ("7x8U3y5z".to_string(), 1)   // 'U'
        ]
    );
}
