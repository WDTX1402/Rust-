use assert_cmd::Command;
use std::fs;
type TestResult = Result<(), Box<dyn std::error::Error>>;

/*#[test]
fn test_arrow() {
    assert_eq!(arrow(4), ("*\n**\n***\n****\n***\n**\n*\n"));
    assert_eq!(arrow(0), (""));
}
*/

/*#[test]
fn test_arrow_loop() {
    let mut cmd = Command::cargo_bin("arrow_loop").unwrap();
    cmd.arg("4").assert().success().stdout("*\n**\n***\n****\n***\n**\n*\n");
}
*/

#[test]
fn test_arrow_loop2() -> TestResult {
    let expected = fs::read_to_string("tests/output2.txt")?;
    Command::cargo_bin("arrow_loop2")?
        .assert()
        .success()
        .stdout(expected);

    Ok(())
}

#[test]
fn test_arrow_loop1() -> TestResult {
    let expected = fs::read_to_string("tests/output1.txt")?;
    Command::cargo_bin("arrow_loop1")?
        .assert()
        .success()
        .stdout(expected);

    Ok(())
}


