fn main() {}
#[allow(dead_code)]
fn grade_list(v:&[i64]) -> Vec<&str> {
    let mut ans = Vec::new();
    for &x in v { 
        if x > 100 {
            ans.push("Invalid Score");
        } else if 95 <= x && x <= 100 {
            ans.push("Excellent A+");
        } else if 81 <= x && x <= 94 {
            ans.push("A");
        } else if 71 <= x && x <= 80 {
            ans.push("B");
        } else if 61 <= x && x <= 70 {
            ans.push("C");
        } else if 50 <= x && x <= 60 {
            ans.push("D");
        } else if 0 <= x && x <= 49 {
            ans.push("Failed F");
        } else if 0 > x {
            ans.push("Invalid Score");
        }
        
  }
  ans
}

#[allow(dead_code)]
fn grade_list_recur(v: &[i64]) -> Vec<&str> {
    if v.len() == 0 {
        Vec::new()
    } else {
        let mut ans = grade_list_recur(&v[..v.len() - 1]);
        let score = v[v.len() - 1]; 

        if score > 100 {
            ans.push("Invalid Score");
        } else if 95 <= score && score <= 100 {
            ans.push("Excellent A+");
        } else if 81 <= score && score <= 94 {
            ans.push("A");
        } else if 71 <= score && score <= 80 {
            ans.push("B");
        } else if 61 <= score && score <= 70 {
            ans.push("C");
        } else if 50 <= score && score <= 60 {
            ans.push("D");
        } else if 0 <= score && score <= 49 {
            ans.push("Failed F");
        } else if score < 0 {
            ans.push("Invalid Score");
        }

        ans
    }
}


#[test]
fn test_grade_list() {
    assert_eq!(grade_list(&[-1, 85, 57, 109]), vec!["Invalid Score", "A", "D", "Invalid Score"]);
    assert_eq!(grade_list(&[-1]), vec!["Invalid Score"]);
    assert_eq!(grade_list(&[109]), vec!["Invalid Score"]);
}

#[test]
fn test_grade_list_recur() {
    assert_eq!(grade_list_recur(&[-1, 85, 57, 109]), vec!["Invalid Score", "A", "D", "Invalid Score"]);
    assert_eq!(grade_list_recur(&[-1]), vec!["Invalid Score"]);
    assert_eq!(grade_list_recur(&[109]), vec!["Invalid Score"]);
}