fn main() {}
#[allow(dead_code)]
fn celcius(v: &[f64]) -> Vec<f64> {
    let mut ans = Vec::new();
    for &x in v {
        ans.push((5.0/9.0)*(x-32.0));
    }
    ans
}
#[allow(dead_code)]
fn celcius_recur(v: &[f64]) -> Vec<f64> {
    if v.len() == 0 {
        Vec::new()
    } else {
        let mut ans = celcius_recur(&v[..v.len() -1]);
        ans.push((5.0/9.0)*(v[v.len() -1]-32.0));
        ans
    }
}

#[test]
fn test_celcius() {
    assert_eq!(celcius(&[]), vec![]);
    assert_eq!(celcius(&[32.0, 100.0, -1.0]), vec![0.0, 37.77777777777778, -18.333333333333336]);
    assert_eq!(celcius(&[100.0]), vec![37.77777777777778]);
    assert_eq!(celcius(&[-1.0]), vec![-18.333333333333336]);
}

#[test]
fn test_celcius_recur() {
    assert_eq!(celcius(&[]), vec![]);
    assert_eq!(celcius(&[32.0, 100.0, -1.0]), vec![0.0, 37.77777777777778, -18.333333333333336]);
    assert_eq!(celcius(&[100.0]), vec![37.77777777777778]);
    assert_eq!(celcius(&[-1.0]), vec![-18.333333333333336]);
}
