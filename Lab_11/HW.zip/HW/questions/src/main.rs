fn main() {
    print!("Hello TA!")
}