use assert_cmd::Command;

#[test]
fn main() {
    let mut cmd = Command::cargo_bin("circle").unwrap();
    cmd.arg("4").assert().success().stdout("a: 50.2656");
}

