use assert_cmd::Command;

#[test]
fn to_farenheit() {
    let mut cmd = Command::cargo_bin("to_farenheit").unwrap();
    cmd.arg("0").assert().success().stdout("f: 32");
}


 
#[test]
fn main() {
    let mut cmd = Command::cargo_bin("temp").unwrap();
    cmd.arg("32").assert().success().stdout("c: 0");
}


