use assert_cmd::Command;


#[test]
fn tst1() {
    let expected = "Player 1: N/A\nPlayer 2: N/A";
    let mut cmd = Command::cargo_bin("list_players").unwrap();
    cmd.assert().success().stdout(expected);
}

#[test]
fn tst2() {
    let expected = "Player 1: Trashcan\nPlayer 2: N/A";
    let mut cmd = Command::cargo_bin("list_players").unwrap();
    cmd.arg("Trashcan").assert().success().stdout(expected);
}

#[test]
fn tst3() {
    let expected = "Player 1: Trashcan\nPlayer 2: Tuscan";
    let mut cmd = Command::cargo_bin("list_players").unwrap();
    cmd.arg("Trashcan").arg("Tuscan").assert().success().stdout(expected);
}

#[test]
fn tst4() {
    let expected = "Player 1: Trashcan\nPlayer 2: Tuscan";
    let mut cmd = Command::cargo_bin("list_players").unwrap();
    cmd.arg("Trashcan").arg("Tuscan").arg("Bob").assert().success().stdout(expected);
}


